export interface Reset{
    UserName: string;
    Password: string,
    Security_Q: number,
    Security_A: string
}