export interface Signup {
    Name: string;
    UserName: string; 
    Password: string;
    Security_Q: number;
    Security_A: string;
    House: number;
}