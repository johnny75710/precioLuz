export interface ResponseL {
    token: any;
    username: string;
    house: string;
}